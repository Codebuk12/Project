﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginFormDesign
{
    public partial class Students : Form
    {
        public Students()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True ");
                SqlCommand cmd = new SqlCommand("usp_SearchStudent", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@Filter", textBox1.Text.Trim());
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);
                DgvStudent.DataSource = dt;
            }
            else
                LoadDataIntoGridview();
        }

        private void LoadDataIntoGridview()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("ViewData", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            DgvStudent.DataSource = dt;
        }

        private void Students_Load(object sender, EventArgs e)
        {
            LoadDataIntoGridview();
        }
    }
}
