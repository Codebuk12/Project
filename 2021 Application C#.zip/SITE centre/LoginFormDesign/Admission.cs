﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginFormDesign
{
    public partial class Admission : Form
    {
        public Admission()
        {
            InitializeComponent();
        }

        private void Admission_Load(object sender, EventArgs e)
        {
            LoadDataIntoGridview();
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
        }

        private void LoadDataIntoGridview()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("ViewData", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dgv.DataSource = dt;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
          if(IsFormValid()== true)
            {
                SaveData();
                LoadDataIntoGridview();
            }
            
        }

        private bool IsFormValid()
        {
           if(txtStName.Text == "")
            {
                MessageBox.Show("Student Name is Required","Invalid",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtStName.Focus();
                return false;
            }
            if (txtFaName.Text == "")
            {
                MessageBox.Show("Father Name is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFaName.Focus();
                return false;
            }
            if (txtCaste.Text == "")
            {
                MessageBox.Show("Caste is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtStName.Focus();
                return false;
            }
            if (Adate.Text == "")
            {
                MessageBox.Show("Date is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Adate.Focus();
                return false;
            }
            if (txtAddress.Text == "")
            {
                MessageBox.Show("Address is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddress.Focus();
                return false;
            }
            if (txtNo.Text == "")
            {
                MessageBox.Show("Cotact No is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNo.Focus();
                return false;
            }
            if (txtEmergencyNo.Text == "")
            {
                MessageBox.Show("Emergency No is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNo.Focus();
                return false;
            }
            if (combStatus.SelectedIndex == -1)
            {
                MessageBox.Show("Plz Select status", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNo.Focus();
                return false;
            }
            return true;
        }

        private void SaveData()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("saveAdmission", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@StudentName   ", txtStName.Text);
            cmd.Parameters.AddWithValue("@FatherName    ", txtFaName.Text);
            cmd.Parameters.AddWithValue("@Class         ", txtClass.Text);
            cmd.Parameters.AddWithValue("@AdmissionDate ", Adate.Value);
            cmd.Parameters.AddWithValue("@Caste         ", txtCaste.Text);
            cmd.Parameters.AddWithValue("@AdmissionFees ", txtAdmission.Text);
            cmd.Parameters.AddWithValue("@StudentAddress", txtAddress.Text);
            cmd.Parameters.AddWithValue("@ContactNo     ", txtNo.Text);
            cmd.Parameters.AddWithValue("@EmergencyNo   ", txtEmergencyNo.Text);
            cmd.Parameters.AddWithValue("@Status        ", combStatus.Text);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data Saved");
            ClearControls();
           
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("updateOxfordStudents", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@RegNoID", Convert.ToInt32(txtRegNo.Text));
                cmd.Parameters.AddWithValue("@StudentName", txtStName.Text);
                cmd.Parameters.AddWithValue("@FatherName", txtFaName.Text);
                cmd.Parameters.AddWithValue("@Class", txtClass.Text);
                cmd.Parameters.AddWithValue("@AdmissionDate", Adate.Value);
                cmd.Parameters.AddWithValue("@Caste", txtCaste.Text);
                cmd.Parameters.AddWithValue("@AdmissionFees", txtAdmission.Text);
                cmd.Parameters.AddWithValue("@StudentAddress", txtAddress.Text);
                cmd.Parameters.AddWithValue("@ContactNo", txtNo.Text);
                cmd.Parameters.AddWithValue("@EmergencyNo", txtEmergencyNo.Text);
                cmd.Parameters.AddWithValue("@Status", combStatus.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data Updated");
                LoadDataIntoGridview();
                ClearControls();
            }
            catch ( Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
           
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("DeleteOxfordStudents", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@RegNoID", txtRegNo.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Deleted Successfully");
            LoadDataIntoGridview();
            con.Close();
            ClearControls();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ClearControls();
        }

        private void ClearControls()
        {
            txtRegNo.Clear();
            txtStName.Clear();
            txtFaName.Clear();
            txtClass.Clear();
            txtCaste.Clear();
            txtAdmission.Clear();
            txtAddress.Clear();
            txtNo.Clear();
            txtEmergencyNo.Clear();
            combStatus.SelectedIndex = -1;
            Adate.Text = DateTime.Now.ToString();
            btnSave.Enabled = true;
            btnDelete.Enabled = false;
            btnUpdate.Enabled = false;

        }

        private void dgv_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
             txtRegNo.Text = dgv.CurrentRow.Cells[0].Value.ToString();
            txtStName.Text = dgv.CurrentRow.Cells[1].Value.ToString();
            txtFaName.Text = dgv.CurrentRow.Cells[2].Value.ToString();
            txtClass.Text = dgv.CurrentRow.Cells[3].Value.ToString();
            Adate.Text = dgv.CurrentRow.Cells[4].Value.ToString();
            txtCaste.Text = dgv.CurrentRow.Cells[5].Value.ToString();
            txtAdmission.Text = dgv.CurrentRow.Cells[6].Value.ToString();
            txtAddress.Text = dgv.CurrentRow.Cells[7].Value.ToString();
            txtNo.Text = dgv.CurrentRow.Cells[8].Value.ToString();
            txtEmergencyNo.Text = dgv.CurrentRow.Cells[9].Value.ToString();
            combStatus.Text = dgv.CurrentRow.Cells[10].Value.ToString();
            btnSave.Enabled = false;
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
            btnReset.Enabled  =  true;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (txtSearch.Text != "")
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True ");
                SqlCommand cmd = new SqlCommand("usp_SearchStudent", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@Filter", txtSearch.Text.Trim());
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);
                dgv.DataSource = dt;
            }
            else
                LoadDataIntoGridview();
            }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
