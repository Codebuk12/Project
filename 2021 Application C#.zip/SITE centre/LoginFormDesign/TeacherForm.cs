﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LoginFormDesign
{
    public partial class TeacherForm : Form
    {
        public TeacherForm()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
           if (IsFormValid() == true)
           {
             SaveData();
             LoadDataIntoGridview();
          }
        }

        private void LoadDataIntoGridview()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True ");
            SqlCommand cmd = new SqlCommand("showData", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dgvTeacher.DataSource = dt;
        }

        private bool IsFormValid()
      {

            if (txtTName.Text == "")
            {
                MessageBox.Show(" Name is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTName.Focus();
                return false;
            }
            if (txtTFatherName.Text == "")
            {
                MessageBox.Show("Father Name is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTFatherName.Focus();
                return false;
            }
            if (txtCINIC.Text == "")
            {
                MessageBox.Show("CINIC is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCINIC.Focus();
                return false;
            }
            if (txtapplied.Text == "")
            {
                MessageBox.Show("Post Applied  is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtapplied.Focus();
                return false;
            }
            if (txtQulfication.Text == "")
            {
                MessageBox.Show("Education is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtQulfication.Focus();
                return false;
            }
            if (txtExperence.Text == "")
            {
                MessageBox.Show("Experenace No is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtExperence.Focus();
                return false;
            }
            if (txtPhone.Text == "")
            {
                MessageBox.Show("phone No is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPhone.Focus();
                return false;
            }
            if (txtRefernce.Text=="")
            {
                MessageBox.Show("Plz Select Refernace", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRefernce.Focus();
                return false;
            }
            return true;
        }

        private void SaveData()
        {

            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("AddTeacher", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@CandidateName", txtTName.Text);
            cmd.Parameters.AddWithValue("@CandidateFather", txtTFatherName.Text);
            cmd.Parameters.AddWithValue("@CNICNo", txtCINIC.Text);
            cmd.Parameters.AddWithValue("@PostApplied", txtapplied.Text);
            cmd.Parameters.AddWithValue("@DOB", dtpDOB.Value);
            cmd.Parameters.AddWithValue("@JobAssigned", dtpJob.Value);
            cmd.Parameters.AddWithValue("@Qualification", txtQulfication.Text);
            cmd.Parameters.AddWithValue("@Experience", txtExperence.Text);
            cmd.Parameters.AddWithValue("@Contact", txtPhone.Text);
            cmd.Parameters.AddWithValue("@AppointmentDate", dtpDateP.Value);
            cmd.Parameters.AddWithValue("@Reference", txtRefernce.Text);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data Saved");
            ClearControls();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ClearControls();
        }

        private void ClearControls()
        {
            txtapplied.Clear();
            txtCINIC.Clear();
            txtExperence.Clear();
            txtPhone.Clear();
            txtQulfication.Clear();
            txtTFatherName.Clear();
            txtTID.Clear();
            txtTName.Clear();
            txtRefernce.Clear();
            
       

        }

        private void TeacherForm_Load(object sender, EventArgs e)
        {
            LoadDataIntoGridview();
        }

        private void dgvTeacher_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtTID.Text =  dgvTeacher.CurrentRow.Cells[0].Value.ToString();
            txtTName.Text = dgvTeacher.CurrentRow.Cells[1].Value.ToString();
            txtTFatherName.Text = dgvTeacher.CurrentRow.Cells[2].Value.ToString();
            txtCINIC.Text = dgvTeacher.CurrentRow.Cells[3].Value.ToString();
            txtapplied.Text = dgvTeacher.CurrentRow.Cells[4].Value.ToString();
            txtQulfication.Text = dgvTeacher.CurrentRow.Cells[5].Value.ToString();
            txtExperence.Text = dgvTeacher.CurrentRow.Cells[6].Value.ToString();
            txtPhone.Text = dgvTeacher.CurrentRow.Cells[7].Value.ToString();
           // dtpDOB.Text = dgvTeacher.CurrentRow.Cells[8].Value.ToString();
           // dtpJob.Text = dgvTeacher.CurrentRow.Cells[9].Value.ToString();
           // dtpDateP.Text = dgvTeacher.CurrentRow.Cells[10].Value.ToString();
            txtRefernce.Text = dgvTeacher.CurrentRow.Cells[11].Value.ToString();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteRecord();
        }

        private void DeleteRecord()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("DeleteData", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@CandidateID", txtTID.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Deleted Successfully");
            LoadDataIntoGridview();
            con.Close();
            ClearControls();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateRecord();
        }

        private void UpdateRecord()
        {


            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("UpdateDataT", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@CandidateID", Convert.ToInt32(txtTID.Text));
            cmd.Parameters.AddWithValue("@CandidateName", txtTName.Text);
            cmd.Parameters.AddWithValue("@CandidateFather", txtTFatherName.Text);
            cmd.Parameters.AddWithValue("@CNICNo", txtCINIC.Text);
            cmd.Parameters.AddWithValue("@PostApplied", txtapplied.Text);
            cmd.Parameters.AddWithValue("@DOB", dtpDOB.Value);
            cmd.Parameters.AddWithValue("@JobAssigned", dtpJob.Value);
            cmd.Parameters.AddWithValue("@Qualification", txtQulfication.Text);
            cmd.Parameters.AddWithValue("@Experience", txtExperence.Text);
            cmd.Parameters.AddWithValue("@Contact", txtPhone.Text);
            cmd.Parameters.AddWithValue("@AppointmentDate", dtpDateP.Value);
            cmd.Parameters.AddWithValue("@Reference", txtRefernce.Text);
            cmd.ExecuteNonQuery();           	
            con.Close();
            MessageBox.Show("Data Updated");
            LoadDataIntoGridview();
            ClearControls();
        }
    }
}
