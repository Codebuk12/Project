﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LoginFormDesign
{
   public static class DBConnection
    {
        public static string GetConnection()
        {

            return @"Data Source=DESKTOP-1ECP5OI\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True";
        }
    }
}
