﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginFormDesign
{
    public partial class FeeStructure : Form
    {
        public FeeStructure()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CalculateFee();
            SaveRecord();
            LoadDataIntoGridview();
        }

        private void LoadDataIntoGridview()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True ");
            SqlCommand cmd = new SqlCommand("ShowDatafee", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dgvFee.DataSource = dt;
        }

        private void SaveRecord()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("SavaFeeRecord", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FeeDate", dtpFee.Value);
            cmd.Parameters.AddWithValue("@ReceiptNo", txtReceiptno.Text);
            cmd.Parameters.AddWithValue("@RegistrationNo", txtRegisterNo.Text);
            cmd.Parameters.AddWithValue("@StudentName", txtStudentName.Text);
            cmd.Parameters.AddWithValue("@FatherName", txtFatherName.Text);
            cmd.Parameters.AddWithValue("@Class", txtClass.Text);
            cmd.Parameters.AddWithValue("@MontlyFeesCoaching ", txtMontlyFee.Text);
            cmd.Parameters.AddWithValue("@AdmissionFeeCoching", txtAdmisionC.Text);
            cmd.Parameters.AddWithValue("@EnglishLanguageFee", txtengLt.Text);
            cmd.Parameters.AddWithValue("@AdmissionFeeEnglish", txtAdmissionEL.Text);
            cmd.Parameters.AddWithValue("@TotalFee", txtTotal.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data Saved");
            CalculateFee();
            DialogResult result = MessageBox.Show("do you want to print recipt?","confirm",MessageBoxButtons.YesNo);
            if(result==DialogResult.Yes)
            {
                
                ReportScreens.FeeReportScreen report = new ReportScreens.FeeReportScreen();
                report.ReceiptNo = Convert.ToInt32(txtReceiptno.Text);
                report.ShowDialog();
            }
            ClearControl();
            LoadDataIntoGridview();
        }

        private void CalculateFee()
        {
          decimal x;
          decimal p =Convert.ToDecimal (txtMontlyFee.Text); 
          decimal q = Convert.ToDecimal(txtAdmisionC.Text);
          decimal y = Convert.ToDecimal(txtengLt.Text);
            decimal z = Convert.ToDecimal(txtAdmissionEL.Text);
            x = (p+q+y+z);
            txtTotal.Text = Convert.ToString(x);
           
        }

        private void FeeStructure_Load(object sender, EventArgs e)
        {
            LoadDataIntoGridview();
        }

        private void dgvFee_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = dgvFee.CurrentRow.Cells[0].Value.ToString();
            dtpFee.Text = dgvFee.CurrentRow.Cells[1].Value.ToString();
            txtReceiptno.Text = dgvFee.CurrentRow.Cells[2].Value.ToString();
            txtRegisterNo.Text = dgvFee.CurrentRow.Cells[3].Value.ToString();
            txtStudentName.Text = dgvFee.CurrentRow.Cells[4].Value.ToString();
            txtFatherName.Text = dgvFee.CurrentRow.Cells[5].Value.ToString();
            txtClass.Text = dgvFee.CurrentRow.Cells[6].Value.ToString();
            txtMontlyFee.Text = dgvFee.CurrentRow.Cells[7].Value.ToString();
            txtAdmisionC.Text = dgvFee.CurrentRow.Cells[8].Value.ToString();
            txtengLt.Text = dgvFee.CurrentRow.Cells[9].Value.ToString();
            txtAdmissionEL.Text = dgvFee.CurrentRow.Cells[10].Value.ToString();
            txtTotal.Text = dgvFee.CurrentRow.Cells[11].Value.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearControl();
        }

        private void ClearControl()
        {
            txtTotal.Clear();
            txtStudentName.Clear();
            txtRegisterNo.Clear();
            txtClass.Clear();
            txtReceiptno.Clear();
            txtMontlyFee.Clear();
            txtSerch.Clear();
            txtFatherName.Clear();
            txtengLt.Clear();
            txtAdmissionEL.Clear();
            txtAdmisionC.Clear();
            txtID.Clear();
            dtpFee.Value = DateTime.Now;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteRecord();
        }

        private void DeleteRecord()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("deleRecord", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@FeeID", txtID.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Deleted Successfully");
            LoadDataIntoGridview();
            con.Close();
            ClearControl();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateRecord();
        }

        private void UpdateRecord()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("updateDataF", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FeeID",txtID.Text);
            cmd.Parameters.AddWithValue("@FeeDate", dtpFee.Value);
            cmd.Parameters.AddWithValue("@ReceiptNo" ,txtReceiptno.Text);
            cmd.Parameters.AddWithValue("@RegistrationNo",txtRegisterNo.Text);
            cmd.Parameters.AddWithValue("@StudentName", txtStudentName.Text);
            cmd.Parameters.AddWithValue("@FatherName", txtFatherName.Text);
            cmd.Parameters.AddWithValue("@Class", txtClass.Text);
            cmd.Parameters.AddWithValue("@MontlyFeesCoaching ", txtMontlyFee.Text);
            cmd.Parameters.AddWithValue("@AdmissionFeeCoching" ,txtAdmisionC.Text);
            cmd.Parameters.AddWithValue("@EnglishLanguageFee",txtengLt.Text);
            cmd.Parameters.AddWithValue("@AdmissionFeeEnglish", txtAdmissionEL.Text);
            cmd.Parameters.AddWithValue("@TotalFee", txtTotal.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data Saved");
            DialogResult result = MessageBox.Show("do you want to print recipt?", "confirm", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {

                ReportScreens.FeeReportScreen report = new ReportScreens.FeeReportScreen();
                report.ReceiptNo = Convert.ToInt32(txtReceiptno.Text);
                report.ShowDialog();
            }
            ClearControl();
            CalculateFee();
            LoadDataIntoGridview();

        }
    }
}
