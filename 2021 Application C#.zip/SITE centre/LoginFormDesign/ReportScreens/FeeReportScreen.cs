﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;

namespace LoginFormDesign.ReportScreens
{
    public partial class FeeReportScreen : Form
    {
        public FeeReportScreen()
        {
            InitializeComponent();
        }
        public int ReceiptNo { get; set; }
        private void FeeReportScreen_Load(object sender, EventArgs e)
        {
            LoadFeeReport();
        }

        private void LoadFeeReport()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("usp_FeeVoucher", con);
            cmd.Parameters.AddWithValue("@ReceiptNo", this.ReceiptNo);
            cmd.CommandType = CommandType.StoredProcedure;
         //   cmd.Parameters.AddWithValue("@ReceiptNo");

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dtFee = new DataTable();
            da.Fill(dtFee);
            //DataTable dtReportData = new DataTable();
            string r;
            r = @"Reports\FeeReport.rpt";
            ShowReport(r, dtFee);
        }

        private void ShowReport(string _reportName, DataTable dt)
        {
            string reportName = _reportName;
            ReportDocument rDoc = new ReportDocument();
            rDoc.Load(reportName);
            rDoc.SetDataSource(dt);
            crystalReportViewer1.ReportSource = rDoc;
            crystalReportViewer1.Refresh();
        }
    }
}
