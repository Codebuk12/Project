﻿using LoginFormDesign.ReportScreens;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LoginFormDesign
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           Admission ad = new Admission();
           ad.ShowDialog();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            TeacherForm Tf = new TeacherForm();
            Tf.ShowDialog();
          
        }                                              

        private void button3_Click(object sender, EventArgs e)
        {
            FeeStructure fs = new FeeStructure();
            fs.ShowDialog();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            FeeReportScreen report = new FeeReportScreen();
            report.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Students rt = new Students();
            rt.ShowDialog();

        }
    }
}