﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginFormDesign
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (IsFormValid() == true)
            {

                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=newOxford;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("OxfordLogin", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                   cmd.Parameters.AddWithValue("@Uname", txtUser.Text);
                  cmd.Parameters.AddWithValue("@Pass", txtPassword.Text);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                con.Close();
                if (dt.Rows.Count>0)
                {
                   
                    Form1 rt = new Form1();
                    this.Hide();
                    rt.ShowDialog();
                  
                }
                else
                {
                    MessageBox.Show("Login Failed");
                }
            }
        }

        private bool IsFormValid()
        {
            if(txtUser.Text == "")
            {
                MessageBox.Show("User Name is Required");
                txtUser.Focus();
                return false;
            }
            if(txtPassword.Text == "")
            {
                MessageBox.Show("Password is Required");
                txtPassword.Focus();
                return false;
            }
            return true;
        }
    }
}
