﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace RigsertForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveRecord();
        }

        private void SaveRecord()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=testDB;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("sava",con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Name",txtemail.Text);
            cmd.Parameters.AddWithValue("@RollNO",txtRoll.Text);
            cmd.Parameters.AddWithValue("@Dept",txtDept.Text);
            cmd.Parameters.AddWithValue("@Email",txtemail.Text);
            cmd.Parameters.AddWithValue("@City",txtCity.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data Saved");
            con.Close();
           



        }
    }
}
