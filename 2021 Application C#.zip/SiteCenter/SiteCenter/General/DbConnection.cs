﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiteCenter.General
{
   public static class DbConnection
    {
        public static string GetConnection()
        {
            return @"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=SiteCenter;Integrated Security=True";
        }
    }
}
