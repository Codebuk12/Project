﻿using SiteCenter.General;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SiteCenter
{
    public partial class AddNewUserScreen : Form
    {
        public AddNewUserScreen()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M2U295E\SQLEXPRESS;Initial Catalog=SiteCenter;Integrated Security=True");
            string query = "insert into users(UserName,Password) Values('" + UserNameTextBox.Text + "','" + PasswordTextBox.Text + "') ";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Success");

        }

        private void AddNewUserScreen_Load(object sender, EventArgs e)
        {

        }
    }
}
