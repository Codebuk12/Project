﻿using SiteCenter.General;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SiteCenter.Screens
{
    public partial class ManageCoursesScreen : TemplateForm
    {
        public ManageCoursesScreen()
        {
            InitializeComponent();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ManageCoursesScreen_Load(object sender, EventArgs e)
        {
            LoadDataIntoGridView();
        }

        private void LoadDataIntoGridView()
        {
            SqlConnection con = new SqlConnection(DbConnection.GetConnection());
            string query = "  Select  CourseID,CourseName,CourseFee,CourseDuration,CreatedBy,CreateDate FROM Courses";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dtCourse = new DataTable();
            da.Fill(dtCourse);
            // maping data to gridview
            CourseListGridView.DataSource = dtCourse; 
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsFormValid() == true)
            {
                SaveData();
               
            }
        }

        private void SaveData()
        {
            SqlConnection con = new SqlConnection(DbConnection.GetConnection());
            SqlCommand cmd = new SqlCommand("savacourse", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@CourseName", comboBox1.Text);
            cmd.Parameters.AddWithValue("@CourseFee", txtfee.Text);
            cmd.Parameters.AddWithValue("@CourseDuration", txtDuration.Text);
            cmd.Parameters.AddWithValue("@CreatedBy", txtcraetedby.Text);
            cmd.Parameters.AddWithValue("@CreateDate", dtpcreated.Value);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data Saved");
            LoadDataIntoGridView();
            clearControll();





        }

        private bool IsFormValid()
        {
            if (comboBox1.Text == "")
            {
                MessageBox.Show("Course Name is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comboBox1.Focus();
                return false;
            }
            if (txtfee.Text == "")
            {
                MessageBox.Show("course Fee is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtfee.Focus();
                return false;
            }
            if (txtDuration.Text == "")
            {
                MessageBox.Show("Course Duration is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDuration.Focus();
                return false;
            }
            if (txtcraetedby.Text == "")
            {
                MessageBox.Show("created by is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtcraetedby.Focus();
                return false;
            }
            if (dtpcreated.Text == "")
            {
                MessageBox.Show("Created date is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dtpcreated.Focus();
                return false;
            }
           
            return true;
        }

        private void CourseListGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = CourseListGridView.CurrentRow.Cells[0].Value.ToString();
            comboBox1.Text = CourseListGridView.CurrentRow.Cells[1].Value.ToString();
            txtfee.Text = CourseListGridView.CurrentRow.Cells[2].Value.ToString();
            txtDuration.Text = CourseListGridView.CurrentRow.Cells[3].Value.ToString();
            txtcraetedby.Text = CourseListGridView.CurrentRow.Cells[4].Value.ToString();
            dtpcreated.Value = Convert.ToDateTime(CourseListGridView.Rows[e.RowIndex].Cells[5].Value.ToString());
            saveToolStripMenuItem.Enabled = false;
            updateToolStripMenuItem.Enabled = true;
            deleteToolStripMenuItem.Enabled = true;


        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clearControll();
            saveToolStripMenuItem.Enabled = true;
            updateToolStripMenuItem.Enabled = false;
            deleteToolStripMenuItem.Enabled = false;

        }

        private void clearControll()
        {
            comboBox1.SelectedItem = null;
            txtID.Clear();
            txtcraetedby.Clear();
            txtDuration.Clear();
            txtfee.Clear();
            dtpcreated.Value = DateTime.Now;
           
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            updateData();
        }

        private void updateData()
        {
            SqlConnection con =new SqlConnection(DbConnection.GetConnection());
            SqlCommand cmd = new SqlCommand("updatadata", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@CourseID",txtID.Text);
            cmd.Parameters.AddWithValue("@CourseName",comboBox1.Text);
            cmd.Parameters.AddWithValue("@CourseFee",txtfee.Text);
            cmd.Parameters.AddWithValue("@CourseDuration",txtDuration.Text);
            cmd.Parameters.AddWithValue("@CreatedBy",txtcraetedby.Text);
            cmd.Parameters.AddWithValue("@CreateDate", dtpcreated.Value);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data update Succus","done",MessageBoxButtons.OK,MessageBoxIcon.Information);
            LoadDataIntoGridView();
            clearControll();
           


        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {


            if (txtID.Text != string.Empty)
            {
                //delete
                deleteData(); 
                MessageBox.Show("Delete Successfull");
                clearControll();
                LoadDataIntoGridView();
            }
            else
            {
                MessageBox.Show("please select student to delete","Valid",MessageBoxButtons.OK,MessageBoxIcon.Question);
            }
           
        }

        private void deleteData()
        {

            SqlConnection con = new SqlConnection(DbConnection.GetConnection());
            SqlCommand cmd = new SqlCommand("deleteData", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@CourseID", txtID.Text);
            cmd.ExecuteNonQuery();
            
            
            con.Close();
        
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


            if (txtsearc.Text != "")
            {
                //Search operation
                SqlConnection con = new SqlConnection(DbConnection.GetConnection());
                string query = "select * from Courses where CourseName Like '%'+'" + txtsearc.Text + "'+'%'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                CourseListGridView.DataSource = dt;
                con.Open();


                con.Close();
            }
        }

        private void CourseListGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
    }

