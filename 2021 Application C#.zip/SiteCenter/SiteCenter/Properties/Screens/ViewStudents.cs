﻿using SiteCenter.General;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SiteCenter.Properties.Screens
{
    public partial class ViewStudents : TemplateForm
    {
        public ViewStudents()
        {
            InitializeComponent();
        }

        private void ViewStudents_Load(object sender, EventArgs e)
        {
            LoadDataIntoGridView();
        }

        private void LoadDataIntoGridView()
        {
            SqlConnection con = new SqlConnection(DbConnection.GetConnection());
            SqlCommand cmd = new SqlCommand("select * from Students",con);
            DataTable dtStudents = new DataTable();;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtStudents);
            dataGridView1.DataSource = dtStudents;
            dataGridView1.Columns[14].Visible = false;
            dataGridView1.Columns[1].Visible = false;

        }

        private void dataGridView1_CellParsing(object sender, DataGridViewCellParsingEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int studeintid = 5;
            AddStudents ADD = new AddStudents();
            ADD.StudentID = studeintid;
            ADD.ShowDialog(); 
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
