﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SiteCenter
{
  public static  class BrowsePicture
    {
        public static void BrowsePic(PictureBox picturebox)
        {
            Stream mystream = null;
            OpenFileDialog opf = new OpenFileDialog();
            opf.Filter = "Chose Imaage(*.jpg; *.png;)| *.jpg; (.png";
            if (opf.ShowDialog() == DialogResult.OK)
            {
                if ((mystream = opf.OpenFile()) != null)
                {
                    string filename = (opf.FileName);
                    if (mystream.Length > 912000)
                    {
                        MessageBox.Show("Image is to big");
                    }
                    else
                    {
                        picturebox.Load(filename);
                    }

                }
            }
        }





    }
}
